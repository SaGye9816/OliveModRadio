package kr.sagye.ui.gui;

import kr.sagye.ui.RenderingHelper;
import net.minecraft.client.Minecraft;
import net.minecraft.client.audio.*;
import net.minecraft.client.gui.*;
import net.minecraft.init.SoundEvents;
import net.minecraft.util.ResourceLocation;

import org.lwjgl.input.Mouse;


public class Radio7 extends Radio {

    private boolean leftpreDown = false;

    private ResourceLocation bg = new ResourceLocation("omod", "textures/gui/7.png");
    private static final ResourceLocation slot = new ResourceLocation("omod", "textures/gui/out.png");

    public void initGui() {
    }

    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        ScaledResolution scaledResolution = new ScaledResolution(mc);

        boolean leftdown = Mouse.isButtonDown(0);
        boolean leftb = false;

        if (leftdown) {
            if (!this.leftpreDown) {
                leftb = true;
            }
            this.leftpreDown = true;
        } else {
            this.leftpreDown = false;
        }

        int factor = scaledResolution.getScaleFactor();

        float bgx = 0;
        float bgy = 0;

        int mx = mouseX / 2;
        int my = mouseY / 2;

        this.bg = new ResourceLocation("omod", "textures/gui/7.png");
        RenderingHelper.drawTexture(bg, bgx, bgy, 1280/factor, 720/factor, 1.0F);

        float btx1 = bgx;
        float bty1 = bgx;

        float btx2 = btx1 + (1280 / 4);
        float bty2 = bty1 + (720 / 4);;

        if (btx1 <= mx && mx <= btx2) { //왼쪽 버튼
            if (bty1 <= my && my <= bty2) {
                if (leftb) {
                    Minecraft.getMinecraft().getSoundHandler().playSound(PositionedSoundRecord.getMasterRecord(SoundEvents.ENTITY_EGG_THROW, 1.0F));
                    Minecraft.getMinecraft().player.closeScreen();
                }
                if (!leftdown) {
                    RenderingHelper.drawTexture(slot, btx1, bty1, 1280/factor, 720/factor, 1.0F);
                }
            }
        }

    }

}


