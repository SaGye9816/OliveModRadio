package kr.sagye.proxy;

public class CommonProxy {

    public void openGUI(int radioNum) {

    }

    public void init(){
    }

}
