package kr.sagye.handler;


import kr.sagye.util.Reference;
import net.minecraftforge.fml.common.Mod;


@Mod.EventBusSubscriber(modid = Reference.MOD_ID)
public class RegisterHandler {
}
