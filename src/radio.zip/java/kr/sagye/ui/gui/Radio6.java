package kr.sagye.ui.gui;

import kr.sagye.sound.RadioSound;
import kr.sagye.ui.RenderingHelper;
import net.minecraft.client.Minecraft;
import net.minecraft.client.audio.PositionedSoundRecord;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.input.Mouse;


public class Radio6 extends Radio {

    private boolean leftpreDown = false;

    private ResourceLocation bg = new ResourceLocation("omod", "textures/gui/6.png");
    private static final ResourceLocation slot = new ResourceLocation("omod", "textures/gui/out.png");

    public void initGui() {
    }

    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        ScaledResolution scaledResolution = new ScaledResolution(mc);

        boolean leftdown = Mouse.isButtonDown(0);
        boolean leftb = false;

        if (leftdown) {
            if (!this.leftpreDown) {
                leftb = true;
            }
            this.leftpreDown = true;
        } else {
            this.leftpreDown = false;
        }

        int factor = scaledResolution.getScaleFactor();

        float bgx = 0;
        float bgy = 0;

        int mx = mouseX / 2;
        int my = mouseY / 2;

        this.bg = new ResourceLocation("omod", "textures/gui/6.png");
        RenderingHelper.drawTexture(bg, bgx, bgy, 1280/factor, 720/factor, 1.0F);

        float btx1 = bgx + 446.48F / 2.0F;
        float bty1 = bgx + 292.0F / 2.0F;

        float btx2 = btx1 + (313 / 4);
        float bty2 = bty1 + (124 / 4);;

        if (btx1 <= mx && mx <= btx2) { //왼쪽 버튼
            if (bty1 <= my && my <= bty2) {
                if (leftb) {
                    Minecraft.getMinecraft().getSoundHandler().playSound(PositionedSoundRecord.getMasterRecord(RadioSound.page, 1.0F));
                    Minecraft.getMinecraft().player.closeScreen();
                }
                if (!leftdown) {
                    RenderingHelper.drawTexture(slot, btx1, bty1, 313/factor, 124/factor, 1.0F);
                }
            }
        }
    }

}


