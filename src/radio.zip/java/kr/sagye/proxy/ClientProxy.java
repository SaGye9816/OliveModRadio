package kr.sagye.proxy;

import kr.sagye.ui.gui.*;
import net.minecraft.client.Minecraft;

import net.minecraftforge.fml.common.FMLCommonHandler;

public class ClientProxy extends CommonProxy {

    public ClientProxy() {
        FMLCommonHandler.instance().bus().register(this);
    }

    @Override
    public void openGUI(int radioNum) {
        Radio gui = null;
        switch (radioNum) {
            case 1:
                gui = new Radio1();
                break;
            case 2:
                gui = new Radio2();
                break;
            case 3:
                gui = new Radio3();
                break;
            case 4:
                gui = new Radio4();
                break;
            case 5:
                gui = new Radio5();
                break;
            case 6:
                gui = new Radio6();
                break;
            case 7:
                gui = new Radio7();
                break;
            case 8:
                gui = new Radio8();
                break;
        }

        Radio finalGui = gui;
        Minecraft.getMinecraft().addScheduledTask(() -> Minecraft.getMinecraft().displayGuiScreen(finalGui));
    }

    @Override
    public void init() {
    }


}